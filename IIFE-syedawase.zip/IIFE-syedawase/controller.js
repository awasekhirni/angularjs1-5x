(function(angular){

    angular.module('UserApp')
         .controller('UserController',['$scope','$http','$log', function(){

         $http({
                        method: 'GET',
                        url: 'https://jsonplaceholder.typicode.com/posts/1'
                    })
                    .then(function(response){
						
                        $scope.title = response.data.title;
						$scope.Body = response.data.body;
                        //$log.info(response);
                    });  
        
    
}]);


})(angular);