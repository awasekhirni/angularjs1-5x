(function(angular){

angular.module('UserApp',[]);

})(angular);
