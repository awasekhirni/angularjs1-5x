
//iife -immediately Invoked function expression
// AKA: self executing annonymous function
(function () {
    "use strict";
    // registering the product management module
    var app = angular.module("productManagement",[]);

    var app = angular.module("payOrderMgmt",[]);

}());